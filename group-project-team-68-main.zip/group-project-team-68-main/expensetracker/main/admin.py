from django.contrib import admin
from .models import Expenses
# Register your models here.
admin.site.register(Expenses)